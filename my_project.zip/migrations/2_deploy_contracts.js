var MyContract = artifacts.require("MyContract");

module.exports = function(deployer) {
    deployer.deploy(MyContract, 100);  // 100 is the initial value for the constructor
}

